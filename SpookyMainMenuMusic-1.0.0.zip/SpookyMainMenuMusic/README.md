## What Does It Do?
This mod will change the Main Menu music to a custom made soundtrack with a spooky atmosphere.

## How to Install:

- Use any compatible mod manager for the easiest installation.

OR

- Make sure you have all dependencies installed.
- Move the `SpookyMainMenuMusic` folder from the `CustomSounds` folder into the `CustomSounds` folder within your `plugins` directory.

## List Of Replaced Sounds:
- Menu1

## This Song Is Custom Made:
I requested this song be created by a friend of mine. The Department of Labor.
More of his work can be found here. https://soundcloud.com/department-of-labor